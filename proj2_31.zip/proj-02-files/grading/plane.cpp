#include "plane.h"
#include "ray.h"
#include <cfloat>
#include <iostream>

// Intersect with the half space defined by the plane.  The plane's normal
// points outside.  If the ray starts on the "inside" side of the plane, be sure
// to record a hit with t=0 as the first entry in hits.
bool Plane::
Intersection(const Ray& ray, std::vector<Hit>& hits) const
{
    // TODO
    // std::cout << "plane.cpp" << std::endl;
    vec3 u = ray.endpoint;
    vec3 v = ray.direction; // / ray.direction.magnitude();
    vec3 p = this->x1;
    vec3 n = this->normal;
    vec3 up = u - p;
    double discriminant = dot(up, n);
    double dotvn = dot(v,n); 

    if (discriminant <= 0)
    {
       if (dotvn <= 0)
       {return false;}
       
       else
       {
          double t1 = -discriminant / dotvn;

          Hit h0, h1;
          h0.object = this;
          h0.t = 0;
          h0.ray_exiting = false;
 
          h1.object = this;
          h1.t = t1;
          h1.ray_exiting = true;

          if (h0.t > small_t)
          {hits.push_back(h0);}

          if (h1.t > small_t)
          {hits.push_back(h1);}

          return true;
       }
    }

    else
    {
       if (dotvn >= 0)
       {return false;}

       else
       {
           double t1 = -discriminant / dotvn;

           Hit h0;
           h0.object = this;
           h0.t = t1;
           h0.ray_exiting = false;

           if (h0.t > small_t)
           {hits.push_back(h0);}
       }
    }

    return false;
}

vec3 Plane::
Normal(const vec3& point, int part) const
{
    return normal;
}
