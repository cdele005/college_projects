#include "sphere.h"
#include "ray.h"
#include <iostream>

// Determine if the ray intersects with the sphere
bool Sphere::Intersection(const Ray& ray, std::vector<Hit>& hits) const
{
    // TODO
    // std::cout << "sphere.cpp :: Intersection" << std::endl;
    /*
    vec3 u = ray.endpoint;
    vec3 v = ray.direction / ray.direction.magnitude();
    vec3 c = this->center;
    double r = this->radius;
    vec3 w = u - c;
    double dotwv = dot(w,v);
    double dotww = dot(w,w);
    double r2 = pow(r,2);
    double discriminant = pow(dotwv,2) - dotww + r2;
    */

    vec3 p0 = ray.endpoint;
    vec3 d = ray.direction;/// ray.direction.magnitude();
    vec3 pc = this->center;
    double r2 = pow(this->radius,2);
    vec3 p0pc = p0 - pc;
    
    double a = dot(d,d);
    double b = 2 * dot(d,p0pc);
    double c = dot(p0pc,p0pc) - r2;

    double discriminant = pow(b,2) - (4 * a * c);

    /*
    std::cout << "ray direction = " << v << std::endl;
    std::cout << "discriminant = " <<  discriminant << std::endl;
    std::cout << "dotwv = " << dotwv << " dotww = " << dotww << std::endl;
    std::cout << "r2 = " << r2 << std::endl;
    */

    if (discriminant <= 0)
    {return false;}

    else
    {
        // double t0 = -dotwv - sqrt(discriminant);
        // double t1 = -dotwv + sqrt(discriminant);
        double t0 = (-b - sqrt(discriminant)) / (2*a);
        double t1 = (-b + sqrt(discriminant)) / (2*a);

        Hit h0,h1;

        h0.object = this;
        h0.t = (t0 < t1) ? t0 : t1;
        h0.ray_exiting = false;
 
        h1.object = this;
        h1.t = (t1 > t0) ? t1 : t0;
        h1.ray_exiting = true;

        if (h0.t > small_t)
        {hits.push_back(h0);}
        if (h1.t > small_t)
        {hits.push_back(h1);}

        // std::cout << "t0: " << t0 << " t1: " << t1 << std::endl;

        return true;
    }

    return false;
}

vec3 Sphere::Normal(const vec3& point, int part) const
{
    vec3 normal;
    // TODO: set the normal
    normal = point - this->center;
    normal = normal / normal.magnitude();
    // std::cout << "sphere.cpp :: Normal" << std::endl;
    
    return normal;
}
