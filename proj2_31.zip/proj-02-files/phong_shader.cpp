#include "light.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"
#include <iostream>

vec3 Phong_Shader::
Shade_Surface(const Ray& ray,const vec3& intersection_point,
    const vec3& same_side_normal,int recursion_depth) const
{
    vec3 color;
    // TODO: determine the color
    // std::cout << "phong_shader.cpp" << std::endl;
    
    vec3 specular;
    vec3 diffuse;
    vec3 ambient =  world.ambient_intensity * color_ambient * world.ambient_color;     

    for (unsigned i = 0; i < world.lights.size(); i++)
    {
        vec3 l = world.lights.at(i)->position - intersection_point;
        l = l / l.magnitude();

        vec3 n = same_side_normal;
        n = n / n.magnitude();
       
        double dotnl = dot(n,l);
        vec3 r = 2 * dotnl * n - l;
        r = r / r.magnitude();
        
        vec3 v = world.camera.position - intersection_point;
        v = v / v.magnitude();
        double dotrv = dot(r,v);
        
        vec3 L = world.lights.at(i)->Emitted_Light(ray);
        vec3 pp0 = intersection_point - world.lights.at(i)->position; 
        double intensity = 1.0 / (pp0.magnitude_squared());
        L = L * intensity;
        
        double diffuse_max = (dotnl > 0) ? dotnl : 0;
        double specular_max = (dotrv > 0) ? dotrv : 0;

        if (world.enable_shadows)
        {
            Hit h;
            Ray r;
            r.endpoint = intersection_point;
            r.direction = world.lights.at(i)->position - intersection_point;

            Object * o = world.Closest_Intersection(r,h);

            if (o == 0)
            {
                diffuse += color_diffuse * diffuse_max * L;
                specular += color_specular * pow(specular_max,specular_power) * L;
            }

            else // o != 0
            {
                vec3 point_hit = r.Point(h.t);
                vec3 light_pos = world.lights.at(i)->position;
                
                double a = (light_pos - intersection_point).magnitude();
                double b = (point_hit - intersection_point).magnitude();

                if (a < b)
                {
                    diffuse += color_diffuse * diffuse_max * L;
                    specular += color_specular * pow(specular_max,specular_power) * L;
                }
            }

        }

        else
        {
            diffuse += color_diffuse * diffuse_max * L;
            specular += color_specular * pow(specular_max,specular_power) * L;
        }
 
        Ray ray2 = ray;
        recursion_depth -= 1;

        if (recursion_depth > 0)
        {world.Cast_Ray(ray2, recursion_depth);}
    }

    color = ambient + diffuse + specular;
    // std::cout << "color = " << color << std::endl;

    return color;
}
